var propeakConfigData = {
    domain: ["@algorisys.com", "@gmail.com"],
    socketPath: 'http://localhost:3002',
    leaveCategory: ['Full Day', 'Half Day'],
    calenderViews: [
        { id: 'DatatableView', desc: 'Datatable View' },
        { id: 'calendarView', desc: 'Calendar View' },
    ],
}