module.exports = {
    ACCESS_TOKEN : 'X-access_token',
    REFRESH_TOKEN : 'X-refresh_token',
    USER_INFO : 'user',
}