module.exports = {
		secret: 'ThisIsYourSecretForJWT,ChangeThis&KeepItSecret',
		secretRefreshToken: 'ThisIsYourSecretFfdgdfgdfgdforJWT,ChangeThis&KeepItSecret'
};