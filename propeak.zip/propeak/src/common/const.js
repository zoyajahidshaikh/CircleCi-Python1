module.exports = {
    ACCESS_TOKEN : 'X-access_token',
    REFRESH_TOKEN : 'X-refresh_token',
    USER_INFO : 'Info',
    serviceHost: '/api',//'http://localhost:3001/api',
    servercert:'/cert/localhost.crt',
    servercertkey:'/cert/localhost.key',
    port:3006
}