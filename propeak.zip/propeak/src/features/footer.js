import React, { Component } from 'react';

export default class Footer extends Component {
	render() {
		return(
			<React.Fragment>
				<div className="row">
				  <footer className="footer">
				      <div className="container text-center">
				          <small>Algorisys Technologies Pvt. Limited</small>
				      </div>
				    </footer>
				</div>
			</React.Fragment>
		)
	}
}